export interface LogisticRegressionModel {
  coefficients: number[]
  intercept: number
  scaler_mean: number[]
  scaler_scale: number[]
  cabin_letter_map: Record<string, number>
  feature_names: string[]
}
