import { type NextRequest, NextResponse } from "next/server"
import { loadModel, predictSurvival } from "@/lib/ml-model"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { age, pclass, sex, fare, sibsp, parch, cabin_letter } = body

    // Cargar modelo
    const model = await loadModel()

    // Mapear letra del camarote a número
    const cabinLetterCode = model.cabin_letter_map[cabin_letter] ?? 8

    // Preparar features en el mismo orden que el modelo
    const features = [
      pclass, // Pclass
      age, // Age
      fare, // Fare
      sibsp, // SibSp
      parch, // Parch
      sex, // Sex (1 = male, 0 = female)
      cabinLetterCode, // CabinLetter_encoded
    ]

    // Hacer predicción
    const { probability, survived } = predictSurvival(features, model)

    return NextResponse.json({
      survived,
      probability_survival: probability,
      probability_death: 1 - probability,
      message: survived === 1 ? "¡Sobreviviste! " : "Lamentablemente no sobreviviste. ",
    })
  } catch (error) {
    console.error("[v0] Prediction error:", error)
    return NextResponse.json({ error: "Error en la predicción" }, { status: 400 })
  }
}
