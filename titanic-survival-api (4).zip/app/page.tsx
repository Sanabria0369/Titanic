"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Ship, Users } from "lucide-react"

export default function TitanicSurvivalPredictor() {
  const [formData, setFormData] = useState({
    age: 30,
    pclass: 1,
    sex: "female",
    fare: 50,
    sibsp: 0,
    parch: 0,
    cabin_letter: "C",
  })

  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const cabinLetters = ["A", "B", "C", "D", "E", "F", "G", "T", "U"]

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]:
        name === "age" || name === "fare"
          ? Number.parseFloat(value)
          : name === "sibsp" || name === "parch" || name === "pclass"
            ? Number.parseInt(value)
            : value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL

      if (!apiUrl) {
        throw new Error("API URL no configurada. Por favor, configura NEXT_PUBLIC_API_URL en las variables de entorno.")
      }

      const response = await fetch(`${apiUrl}/api/predict/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          age: formData.age,
          pclass: formData.pclass,
          sex: formData.sex,
          fare: formData.fare,
          sibsp: formData.sibsp,
          parch: formData.parch,
          cabin_letter: formData.cabin_letter,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Error en la predicción")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-black p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12 pt-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Ship className="w-10 h-10 text-lime-400 drop-shadow-lg" style={{ textShadow: "0 0 10px #84cc16" }} />
            <h1 className="text-5xl font-bold text-lime-400 drop-shadow-lg" style={{ textShadow: "0 0 20px #84cc16" }}>
              Titanic Survival Predictor
            </h1>
            <Ship className="w-10 h-10 text-lime-400 drop-shadow-lg" style={{ textShadow: "0 0 10px #84cc16" }} />
          </div>
          <p className="text-lime-300 text-lg" style={{ textShadow: "0 0 10px #84cc1666" }}>
            Descubre si hubieras sobrevivido al Titanic usando regresión logística
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-black border-2 border-lime-500 p-4" style={{ boxShadow: "0 0 15px #84cc1644" }}>
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6 text-lime-400" />
              <div>
                <p className="text-lime-300 text-sm">Pasajeros</p>
                <p className="text-lime-400 font-bold">2,224</p>
              </div>
            </div>
          </Card>
          <Card className="bg-black border-2 border-lime-500 p-4" style={{ boxShadow: "0 0 15px #84cc1644" }}>
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6 text-lime-400" />
              <div>
                <p className="text-lime-300 text-sm">Sobrevivientes</p>
                <p className="text-lime-400 font-bold">710 (32%)</p>
              </div>
            </div>
          </Card>
          <Card className="bg-black border-2 border-lime-500 p-4" style={{ boxShadow: "0 0 15px #84cc1644" }}>
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6 text-lime-400" />
              <div>
                <p className="text-lime-300 text-sm">Fallecidos</p>
                <p className="text-lime-400 font-bold">1,514 (68%)</p>
              </div>
            </div>
          </Card>
        </div>

        <Card className="bg-black border-2 border-lime-500 p-8" style={{ boxShadow: "0 0 30px #84cc1655" }}>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Edad */}
              <div>
                <label className="block text-sm font-semibold text-lime-300 mb-3">
                  Edad: <span className="text-lime-400 text-lg">{formData.age} años</span>
                </label>
                <input
                  type="range"
                  name="age"
                  min="1"
                  max="80"
                  value={formData.age}
                  onChange={handleChange}
                  className="w-full h-2 bg-gray-900 rounded-lg appearance-none cursor-pointer accent-lime-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1</span>
                  <span>80</span>
                </div>
              </div>

              {/* Clase de pasajero */}
              <div>
                <label className="block text-sm font-semibold text-lime-300 mb-3">Clase de Pasajero</label>
                <select
                  name="pclass"
                  value={formData.pclass}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-gray-950 border-2 border-lime-500 rounded-lg text-lime-400 focus:ring-2 focus:ring-lime-400 focus:border-transparent"
                >
                  <option value="1">Primera Clase (Lujo)</option>
                  <option value="2">Segunda Clase (Confort)</option>
                  <option value="3">Tercera Clase (Económica)</option>
                </select>
              </div>

              {/* Sexo */}
              <div>
                <label className="block text-sm font-semibold text-lime-300 mb-3">Sexo</label>
                <select
                  name="sex"
                  value={formData.sex}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-gray-950 border-2 border-lime-500 rounded-lg text-lime-400 focus:ring-2 focus:ring-lime-400 focus:border-transparent"
                >
                  <option value="female">Mujer</option>
                  <option value="male">Hombre</option>
                </select>
              </div>

              {/* Tarifa */}
              <div>
                <label className="block text-sm font-semibold text-lime-300 mb-3">
                  Tarifa: <span className="text-lime-400 text-lg">${formData.fare.toFixed(2)}</span>
                </label>
                <input
                  type="range"
                  name="fare"
                  min="0"
                  max="500"
                  step="5"
                  value={formData.fare}
                  onChange={handleChange}
                  className="w-full h-2 bg-gray-900 rounded-lg appearance-none cursor-pointer accent-lime-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>$0</span>
                  <span>$500</span>
                </div>
              </div>

              {/* Hermanos/Cónyuge */}
              <div>
                <label className="block text-sm font-semibold text-lime-300 mb-3">Hermanos/Cónyuge a bordo</label>
                <input
                  type="number"
                  name="sibsp"
                  min="0"
                  max="8"
                  value={formData.sibsp}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-gray-950 border-2 border-lime-500 rounded-lg text-lime-400 focus:ring-2 focus:ring-lime-400 focus:border-transparent"
                />
              </div>

              {/* Padres/Hijos */}
              <div>
                <label className="block text-sm font-semibold text-lime-300 mb-3">Padres/Hijos a bordo</label>
                <input
                  type="number"
                  name="parch"
                  min="0"
                  max="6"
                  value={formData.parch}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-gray-950 border-2 border-lime-500 rounded-lg text-lime-400 focus:ring-2 focus:ring-lime-400 focus:border-transparent"
                />
              </div>

              {/* Letra del Camarote */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-lime-300 mb-3">Letra del Camarote</label>
                <div className="grid grid-cols-9 gap-2">
                  {cabinLetters.map((letter) => (
                    <button
                      key={letter}
                      type="button"
                      onClick={() => setFormData((prev) => ({ ...prev, cabin_letter: letter }))}
                      className={`py-2 px-3 rounded-lg font-semibold transition ${
                        formData.cabin_letter === letter
                          ? "bg-lime-500 text-black border-2 border-lime-300"
                          : "bg-gray-950 text-lime-400 border-2 border-lime-600 hover:border-lime-400"
                      }`}
                    >
                      {letter}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-lime-500 hover:bg-lime-400 text-black font-bold py-3 rounded-lg transition text-lg"
            >
              {loading ? "Prediciendo tu destino..." : "Predecir Supervivencia"}
            </Button>
          </form>

          {result && (
            <div
              className={`mt-8 p-8 rounded-lg border-2 text-center transition-all ${
                result.survived ? "bg-black border-lime-500" : "bg-black border-red-600"
              }`}
              style={{
                boxShadow: result.survived ? "0 0 30px #84cc1655" : "0 0 30px #dc262655",
              }}
            >
              <h2 className={`text-3xl font-bold mb-4 ${result.survived ? "text-lime-400" : "text-red-500"}`}>
                {result.message}
              </h2>

              <div className="mb-6 p-4 bg-gray-950 rounded-lg border border-lime-600">
                <p className="text-lime-300 text-sm mb-2">Nivel de Confianza del Modelo</p>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="w-full bg-gray-900 rounded-full h-4 overflow-hidden border border-lime-600">
                      <div
                        className={`h-full transition-all ${
                          Math.abs(result.survival_probability - 0.5) > 0.3 ? "bg-lime-500" : "bg-yellow-500"
                        }`}
                        style={{ width: `${Math.abs(result.survival_probability - 0.5) * 200}%` }}
                      />
                    </div>
                  </div>
                  <span
                    className={`ml-4 font-bold text-lg ${
                      Math.abs(result.survival_probability - 0.5) > 0.3 ? "text-lime-400" : "text-yellow-400"
                    }`}
                  >
                    {Math.abs(result.survival_probability - 0.5) > 0.3 ? "ALTA" : "MEDIA"}
                  </span>
                </div>
                <p className="text-gray-400 text-xs mt-2">
                  {Math.abs(result.survival_probability - 0.5) > 0.3
                    ? "El modelo está muy seguro de esta predicción"
                    : "El modelo tiene dudas, el resultado es incierto"}
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-center gap-4">
                  <div className="flex-1">
                    <p className="text-lime-300 text-sm mb-1">Supervivencia</p>
                    <div className="w-full bg-gray-900 rounded-full h-3 overflow-hidden border border-lime-600">
                      <div
                        className="bg-lime-500 h-full transition-all"
                        style={{ width: `${result.survival_probability * 100}%` }}
                      />
                    </div>
                    <p className="text-lime-400 font-bold mt-1">{(result.survival_probability * 100).toFixed(1)}%</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-red-400 text-sm mb-1">No Supervivencia</p>
                    <div className="w-full bg-gray-900 rounded-full h-3 overflow-hidden border border-red-600">
                      <div
                        className="bg-red-600 h-full transition-all"
                        style={{ width: `${result.death_probability * 100}%` }}
                      />
                    </div>
                    <p className="text-red-400 font-bold mt-1">{(result.death_probability * 100).toFixed(1)}%</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-lime-600">
                <p className="text-gray-500 text-xs">
                  Precisión del modelo: ~80% | Algoritmo: Regresión Logística | Dataset: 891 pasajeros históricos
                </p>
              </div>
            </div>
          )}

          {error && (
            <div
              className="mt-8 p-6 rounded-lg bg-black border-2 border-red-600"
              style={{ boxShadow: "0 0 15px #dc262655" }}
            >
              <p className="text-red-500 font-bold"> Error: {error}</p>
            </div>
          )}
        </Card>

        <div className="mt-12 text-center text-gray-600 text-sm">
          <p className="mb-2 text-lime-600">Modelo entrenado con regresión logística</p>
          <p className="text-lime-600">Datos históricos del RMS Titanic (1912)</p>
        </div>
      </div>
    </div>
  )
}
