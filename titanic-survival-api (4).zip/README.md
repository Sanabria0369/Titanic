# Titanic Survival Predictor - Django + Next.js

Una aplicación web completa que predice si hubieras sobrevivido al Titanic usando un modelo de regresión logística. Backend en Django desplegado en la nube, frontend en Next.js.

## Características

- **Backend Django**: API REST con regresión logística
- **Modelo ML**: Entrenado con tu dataset del Titanic
- **Interfaz Interactiva**: Formulario intuitivo en Next.js
- **Análisis Probabilístico**: Muestra probabilidades de supervivencia
- **Despliegue en Nube**: Backend en Render/Railway, Frontend en Vercel

## Arquitectura

\`\`\`
┌─────────────────────────────────────────────────────────┐
│                    Frontend (Vercel)                    │
│                      Next.js + React                    │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP/REST
                         ▼
┌─────────────────────────────────────────────────────────┐
│              Backend (Render/Railway)                   │
│                   Django REST API                       │
│         Regresión Logística (scikit-learn)              │
└─────────────────────────────────────────────────────────┘
\`\`\`

## Datos Utilizados

El modelo se entrena con el dataset del Titanic que incluye:
- **Edad**: Edad del pasajero (1-80 años)
- **Clase**: Clase de pasajero (1ª, 2ª, 3ª)
- **Sexo**: Género del pasajero (male/female)
- **Tarifa**: Precio del boleto ($0-$500)
- **Familia**: Hermanos/Cónyuge y Padres/Hijos a bordo
- **Camarote**: Letra del camarote (A-U)

## Modelo ML

- **Algoritmo**: Regresión Logística
- **Precisión**: ~80% en datos de prueba
- **Features**: 7 características normalizadas
- **Framework**: scikit-learn
- **Dataset**: 891 pasajeros históricos del Titanic

## Instalación Local

### Backend Django

\`\`\`bash
cd backend
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py runserver
\`\`\`

La API estará disponible en `http://localhost:8000`

### Frontend Next.js

\`\`\`bash
npm install
npm run dev
\`\`\`

El frontend estará disponible en `http://localhost:3000`

Configura la variable de entorno:
\`\`\`bash
NEXT_PUBLIC_API_URL=http://localhost:8000
\`\`\`

## Despliegue en la Nube

### Backend en Render

1. Ve a [render.com](https://render.com)
2. Conecta tu repositorio de GitHub
3. Crea un nuevo servicio Web
4. Configura:
   - **Root Directory**: `backend`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn config.wsgi:application --bind 0.0.0.0:8000`
5. Agrega variables de entorno:
   - `SECRET_KEY`: Genera una clave segura
   - `DEBUG`: `False`
   - `ALLOWED_HOSTS`: `*.onrender.com`
   - `CORS_ALLOWED_ORIGINS`: Tu dominio de Vercel

### Frontend en Vercel

1. Ve a [vercel.com](https://vercel.com)
2. Conecta tu repositorio de GitHub
3. Vercel detectará automáticamente que es Next.js
4. Configura la variable de entorno:
   - `NEXT_PUBLIC_API_URL`: URL de tu API Django en Render

Ver `DEPLOYMENT.md` para instrucciones detalladas.

## Estructura del Proyecto

\`\`\`
titanic-survival-api/
├── backend/                    # Django Backend
│   ├── config/
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── wsgi.py
│   ├── prediction/
│   │   ├── models.py
│   │   ├── views.py
│   │   ├── serializers.py
│   │   ├── ml_model.py        # Modelo de regresión logística
│   │   └── urls.py
│   ├── manage.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── render.yaml
├── app/                        # Next.js Frontend
│   ├── page.tsx               # Página principal
│   ├── layout.tsx
│   └── globals.css
├── components/
│   └── ui/
├── .env.local.example
├── DEPLOYMENT.md
└── README.md
\`\`\`

## API Endpoints

### POST /api/predict/

Realiza una predicción de supervivencia.

**Request:**
\`\`\`json
{
  "age": 25,
  "pclass": 3,
  "sex": "male",
  "fare": 7.75,
  "sibsp": 0,
  "parch": 0,
  "cabin_letter": "U"
}
\`\`\`

**Response:**
\`\`\`json
{
  "survived": false,
  "survival_probability": 0.15,
  "death_probability": 0.85,
  "message": "No sobrevivió"
}
\`\`\`

### GET /api/history/

Obtiene el historial de predicciones realizadas.

### GET /api/health/

Verifica que la API está funcionando.

## Tecnologías

**Backend:**
- Django 4.2
- Django REST Framework
- scikit-learn
- pandas, numpy
- gunicorn

**Frontend:**
- Next.js 16
- React 19
- TypeScript
- Tailwind CSS v4
- shadcn/ui

**Despliegue:**
- Render (Backend)
- Vercel (Frontend)

## Datos Históricos del Titanic

- **Total de pasajeros**: 2,224
- **Sobrevivientes**: 710 (32%)
- **Fallecidos**: 1,514 (68%)

## Notas Importantes

- El modelo se entrena automáticamente en el primer inicio del servidor
- El modelo se guarda en pickle para futuras predicciones
- Las predicciones son estimaciones probabilísticas basadas en patrones históricos
- En producción, considera usar PostgreSQL en lugar de SQLite

## Solución de Problemas

Ver `DEPLOYMENT.md` para solucionar problemas comunes de despliegue.

## Licencia

MIT

## Autor

Creado con v0.app
