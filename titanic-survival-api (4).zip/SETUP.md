# Titanic Survival Predictor - Setup

## Generar el Modelo ML

Antes de ejecutar la aplicación, necesitas generar el modelo de regresión logística:

\`\`\`bash
npm run generate-model
\`\`\`

Este comando:
1. Descarga el dataset del Titanic desde el URL proporcionado
2. Prepara y normaliza los datos
3. Entrena un modelo de regresión logística
4. Exporta el modelo a `public/model.json`

## Ejecutar en desarrollo

\`\`\`bash
npm run dev
\`\`\`

Abre [http://localhost:3000](http://localhost:3000)

## Desplegar en Vercel

El modelo se genera automáticamente durante el build:

\`\`\`bash
npm run build
\`\`\`

Luego despliega normalmente en Vercel.
