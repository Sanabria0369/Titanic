import pickle
import json
import numpy as np
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs

# Cargar modelo y scaler
try:
    with open('model.pkl', 'rb') as f:
        model = pickle.load(f)
    with open('scaler.pkl', 'rb') as f:
        scaler = pickle.load(f)
except:
    model = None
    scaler = None

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)
        
        try:
            data = json.loads(body.decode('utf-8'))
            
            # Extraer características
            pclass = int(data.get('pclass', 3))
            age = float(data.get('age', 30))
            fare = float(data.get('fare', 50))
            sibsp = int(data.get('sibsp', 0))
            parch = int(data.get('parch', 0))
            sex = int(data.get('sex', 0))  # 0 = female, 1 = male
            cabin_letter = int(data.get('cabin_letter', 20))  # encoded
            
            # Preparar features en el mismo orden que el entrenamiento
            features = np.array([[pclass, age, fare, sibsp, parch, sex, cabin_letter]])
            
            # Escalar
            features_scaled = scaler.transform(features)
            
            # Predecir
            prediction = model.predict(features_scaled)[0]
            probability = model.predict_proba(features_scaled)[0]
            
            response = {
                'survived': int(prediction),
                'probability_death': float(probability[0]),
                'probability_survival': float(probability[1]),
                'message': 'Sobreviviste!' if prediction == 1 else 'Lamentablemente no sobreviviste.'
            }
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))
            
        except Exception as e:
            self.send_response(400)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({'error': str(e)}).encode('utf-8'))
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
