import type { LogisticRegressionModel } from "@/types/ml"

let cachedModel: LogisticRegressionModel | null = null

export async function loadModel(): Promise<LogisticRegressionModel> {
  if (cachedModel) {
    return cachedModel
  }

  try {
    const response = await fetch("/model.json")
    if (!response.ok) {
      throw new Error("Failed to load model")
    }
    cachedModel = await response.json()
    return cachedModel
  } catch (error) {
    console.error("[v0] Error loading model:", error)
    throw error
  }
}

export function standardScaleFeatures(features: number[], mean: number[], scale: number[]): number[] {
  return features.map((feature, idx) => (feature - mean[idx]) / scale[idx])
}

export function predictSurvival(
  features: number[],
  model: LogisticRegressionModel,
): { probability: number; survived: number } {
  // Escalar features
  const scaledFeatures = standardScaleFeatures(features, model.scaler_mean, model.scaler_scale)

  // Calcular logit: z = w·x + b
  let z = model.intercept
  for (let i = 0; i < scaledFeatures.length; i++) {
    z += model.coefficients[i] * scaledFeatures[i]
  }

  // Aplicar función sigmoide: 1 / (1 + e^-z)
  const probability = 1 / (1 + Math.exp(-z))
  const survived = probability > 0.5 ? 1 : 0

  return { probability, survived }
}
