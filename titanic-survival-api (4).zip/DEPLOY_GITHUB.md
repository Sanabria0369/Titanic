# Despliegue en la Nube con GitHub

Este proyecto está configurado para desplegar en la nube sin localhost ni stand alone.

## Arquitectura

- **Frontend**: Next.js en Vercel
- **Backend**: Django en Render o Railway
- **Repositorio**: GitHub

## Paso 1: Preparar el Repositorio en GitHub

1. Crea un repositorio en GitHub
2. Sube todo el código:
   \`\`\`bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/tu-usuario/titanic-api.git
   git push -u origin main
   \`\`\`

## Paso 2: Desplegar Backend Django en Render

1. Ve a https://render.com
2. Crea una cuenta y conecta tu GitHub
3. Crea un nuevo "Web Service"
4. Selecciona tu repositorio
5. Configura:
   - **Name**: titanic-api-backend
   - **Environment**: Python 3
   - **Build Command**: `pip install -r backend/requirements.txt && python backend/manage.py migrate`
   - **Start Command**: `gunicorn config.wsgi:application --chdir backend`
   - **Root Directory**: `backend`

6. Agrega variables de entorno:
   - `ALLOWED_HOSTS`: tu-dominio-render.onrender.com
   - `DEBUG`: False
   - `SECRET_KEY`: genera una clave segura

7. Deploy

## Paso 3: Desplegar Frontend en Vercel

1. Ve a https://vercel.com
2. Crea una cuenta y conecta tu GitHub
3. Importa tu repositorio
4. Configura:
   - **Framework**: Next.js
   - **Root Directory**: ./

5. Agrega variables de entorno:
   - `NEXT_PUBLIC_API_URL`: https://tu-dominio-render.onrender.com

6. Deploy

## Verificación

- Frontend: https://tu-proyecto.vercel.app
- Backend API: https://tu-dominio-render.onrender.com/api/predict/

Ambos están en la nube, sin localhost.
