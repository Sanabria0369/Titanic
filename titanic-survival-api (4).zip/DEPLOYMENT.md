# Guía de Despliegue - Titanic Survival API

## Arquitectura

- **Backend**: Django REST API (Render o Railway)
- **Frontend**: Next.js (Vercel)
- **Modelo ML**: Regresión Logística (scikit-learn)

## Despliegue del Backend Django en Render

### Paso 1: Preparar el repositorio

1. Crea un repositorio en GitHub con la carpeta `backend/`
2. Asegúrate de que `requirements.txt` esté en la raíz de `backend/`

### Paso 2: Crear servicio en Render

1. Ve a [render.com](https://render.com)
2. Conecta tu repositorio de GitHub
3. Crea un nuevo servicio Web
4. Configura:
   - **Name**: `titanic-api`
   - **Environment**: Python 3.11
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn config.wsgi:application --bind 0.0.0.0:8000`
   - **Root Directory**: `backend`

### Paso 3: Variables de entorno en Render

Agrega estas variables en el dashboard de Render:

\`\`\`
SECRET_KEY=<genera-una-clave-segura>
DEBUG=False
ALLOWED_HOSTS=*.onrender.com
CORS_ALLOWED_ORIGINS=http://localhost:3000,https://tu-frontend-domain.com
\`\`\`

### Paso 4: Obtener la URL de la API

Una vez desplegado, Render te dará una URL como:
\`\`\`
https://titanic-api-xxxxx.onrender.com
\`\`\`

## Despliegue del Frontend en Vercel

### Paso 1: Preparar el repositorio

1. Crea un repositorio en GitHub con la carpeta raíz del frontend
2. Asegúrate de que `package.json` esté en la raíz

### Paso 2: Desplegar en Vercel

1. Ve a [vercel.com](https://vercel.com)
2. Conecta tu repositorio de GitHub
3. Vercel detectará automáticamente que es Next.js
4. Configura las variables de entorno:
   - `NEXT_PUBLIC_API_URL=https://titanic-api-xxxxx.onrender.com`

### Paso 3: Deploy

Haz clic en "Deploy" y espera a que se complete.

## Alternativa: Despliegue en Railway

### Backend en Railway

1. Ve a [railway.app](https://railway.app)
2. Conecta tu repositorio de GitHub
3. Crea un nuevo proyecto
4. Selecciona Python como runtime
5. Configura las variables de entorno igual que en Render

## Pruebas

### Verificar que la API funciona

\`\`\`bash
curl https://tu-api-url/api/health/
\`\`\`

Deberías recibir:
\`\`\`json
{
  "status": "ok",
  "message": "API Titanic funcionando correctamente"
}
\`\`\`

### Hacer una predicción

\`\`\`bash
curl -X POST https://tu-api-url/api/predict/ \
  -H "Content-Type: application/json" \
  -d '{
    "age": 25,
    "pclass": 3,
    "sex": "male",
    "fare": 7.75,
    "sibsp": 0,
    "parch": 0,
    "cabin_letter": "U"
  }'
\`\`\`

## Solución de problemas

### Error de CORS

Si ves errores de CORS, verifica que `CORS_ALLOWED_ORIGINS` en Django incluya tu dominio de Vercel.

### El modelo no se entrena

Asegúrate de que:
1. La URL del dataset es accesible
2. Tienes conexión a internet en el servidor
3. Las dependencias de scikit-learn están instaladas

### La API devuelve 500

Revisa los logs en Render/Railway para ver el error específico.

## Estructura del Proyecto

\`\`\`
titanic-survival-api/
├── backend/
│   ├── config/
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── wsgi.py
│   ├── prediction/
│   │   ├── models.py
│   │   ├── views.py
│   │   ├── serializers.py
│   │   ├── ml_model.py
│   │   └── urls.py
│   ├── manage.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── render.yaml
├── app/
│   ├── page.tsx
│   └── layout.tsx
├── components/
│   └── ui/
├── .env.local.example
└── DEPLOYMENT.md
\`\`\`

## Notas Importantes

- El modelo se entrena automáticamente en el primer inicio del servidor
- El modelo se guarda en pickle para futuras predicciones
- La base de datos SQLite se crea automáticamente
- En producción, considera usar PostgreSQL en lugar de SQLite
