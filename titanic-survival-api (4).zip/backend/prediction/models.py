from django.db import models

class TitanicPrediction(models.Model):
    passenger_id = models.IntegerField()
    age = models.FloatField()
    pclass = models.IntegerField()
    sex = models.CharField(max_length=10)
    fare = models.FloatField()
    sibsp = models.IntegerField()
    parch = models.IntegerField()
    cabin_letter = models.CharField(max_length=1, null=True, blank=True)
    predicted_survival = models.BooleanField()
    survival_probability = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Passenger {self.passenger_id} - {'Survived' if self.predicted_survival else 'Did not survive'}"
