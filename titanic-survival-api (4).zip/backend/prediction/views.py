from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .serializers import PredictionSerializer, TitanicPredictionSerializer
from .models import TitanicPrediction
from .ml_model import titanic_model

@api_view(['POST'])
def predict_survival(request):
    """Predice la supervivencia de un pasajero del Titanic"""
    serializer = PredictionSerializer(data=request.data)
    
    if serializer.is_valid():
        try:
            data = serializer.validated_data
            
            # Hacer predicción
            result = titanic_model.predict(
                age=data['age'],
                pclass=data['pclass'],
                sex=data['sex'],
                fare=data['fare'],
                sibsp=data['sibsp'],
                parch=data['parch'],
                cabin_letter=data.get('cabin_letter', 'U')
            )
            
            # Guardar predicción en base de datos
            prediction_obj = TitanicPrediction.objects.create(
                passenger_id=0,
                age=data['age'],
                pclass=data['pclass'],
                sex=data['sex'],
                fare=data['fare'],
                sibsp=data['sibsp'],
                parch=data['parch'],
                cabin_letter=data.get('cabin_letter', 'U'),
                predicted_survival=result['survived'],
                survival_probability=result['survival_probability']
            )
            
            return Response({
                'survived': result['survived'],
                'survival_probability': result['survival_probability'],
                'death_probability': result['death_probability'],
                'message': 'Sobrevivió' if result['survived'] else 'No sobrevivió'
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def prediction_history(request):
    """Obtiene el historial de predicciones"""
    predictions = TitanicPrediction.objects.all()[:100]
    serializer = TitanicPredictionSerializer(predictions, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def health_check(request):
    """Health check endpoint"""
    return Response({'status': 'ok', 'message': 'API Titanic funcionando correctamente'})
