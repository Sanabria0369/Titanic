import pickle
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import requests
from io import StringIO
import os

class TitanicModel:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.feature_names = ['Pclass', 'Age', 'Fare', 'SibSp', 'Parch', 'Sex_male', 'CabinLetter_encoded']
        self.load_or_train_model()

    def load_or_train_model(self):
        """Carga el modelo si existe, sino lo entrena"""
        model_path = os.path.join(os.path.dirname(__file__), 'titanic_model.pkl')
        scaler_path = os.path.join(os.path.dirname(__file__), 'scaler.pkl')
        
        if os.path.exists(model_path) and os.path.exists(scaler_path):
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
            with open(scaler_path, 'rb') as f:
                self.scaler = pickle.load(f)
        else:
            self.train_model()

    def train_model(self):
        """Entrena el modelo con el dataset del Titanic"""
        try:
            # Descargar dataset
            url = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/titanic-PfabawRZpCY3WuMzJpfhfIiwlxcjdv.csv"
            response = requests.get(url)
            df = pd.read_csv(StringIO(response.text))
            
            # Preparar datos
            df['Sex'] = df['Sex'].map({'male': 1, 'female': 0})
            df['CabinLetter'] = df['Cabin'].fillna('U').str[0]
            cabin_mapping = {letter: i for i, letter in enumerate(sorted(df['CabinLetter'].unique()))}
            df['CabinLetter_encoded'] = df['CabinLetter'].map(cabin_mapping)
            
            # Llenar valores faltantes
            df['Age'].fillna(df['Age'].median(), inplace=True)
            df['Fare'].fillna(df['Fare'].median(), inplace=True)
            
            # Seleccionar features
            X = df[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch', 'Sex', 'CabinLetter_encoded']]
            X.columns = self.feature_names
            y = df['Survived']
            
            # Normalizar
            self.scaler = StandardScaler()
            X_scaled = self.scaler.fit_transform(X)
            
            # Entrenar modelo
            self.model = LogisticRegression(max_iter=1000, random_state=42)
            self.model.fit(X_scaled, y)
            
            # Guardar modelo
            model_path = os.path.join(os.path.dirname(__file__), 'titanic_model.pkl')
            scaler_path = os.path.join(os.path.dirname(__file__), 'scaler.pkl')
            
            with open(model_path, 'wb') as f:
                pickle.dump(self.model, f)
            with open(scaler_path, 'wb') as f:
                pickle.dump(self.scaler, f)
                
            print("Modelo entrenado y guardado exitosamente")
        except Exception as e:
            print(f"Error entrenando modelo: {e}")
            raise

    def predict(self, age, pclass, sex, fare, sibsp, parch, cabin_letter='U'):
        """Predice la supervivencia de un pasajero"""
        try:
            # Convertir sex a número
            sex_encoded = 1 if sex.lower() == 'male' else 0
            
            # Codificar cabin letter
            cabin_mapping = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'T': 7, 'U': 8}
            cabin_encoded = cabin_mapping.get(cabin_letter.upper(), 8)
            
            # Preparar features
            features = np.array([[pclass, age, fare, sibsp, parch, sex_encoded, cabin_encoded]])
            
            # Normalizar
            features_scaled = self.scaler.transform(features)
            
            # Predecir
            prediction = self.model.predict(features_scaled)[0]
            probability = self.model.predict_proba(features_scaled)[0]
            
            return {
                'survived': bool(prediction),
                'survival_probability': float(probability[1]),
                'death_probability': float(probability[0])
            }
        except Exception as e:
            print(f"Error en predicción: {e}")
            raise

# Instancia global del modelo
titanic_model = TitanicModel()
