from django.urls import path
from . import views

urlpatterns = [
    path('predict/', views.predict_survival, name='predict_survival'),
    path('history/', views.prediction_history, name='prediction_history'),
    path('health/', views.health_check, name='health_check'),
]
