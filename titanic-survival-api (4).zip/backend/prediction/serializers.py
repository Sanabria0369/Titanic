from rest_framework import serializers
from .models import TitanicPrediction

class PredictionSerializer(serializers.Serializer):
    age = serializers.FloatField(min_value=0, max_value=120)
    pclass = serializers.IntegerField(min_value=1, max_value=3)
    sex = serializers.CharField(max_length=10)
    fare = serializers.FloatField(min_value=0)
    sibsp = serializers.IntegerField(min_value=0)
    parch = serializers.IntegerField(min_value=0)
    cabin_letter = serializers.CharField(max_length=1, required=False, allow_blank=True)

class TitanicPredictionSerializer(serializers.ModelSerializer):
    class Meta:
        model = TitanicPrediction
        fields = ['id', 'passenger_id', 'age', 'pclass', 'sex', 'fare', 'sibsp', 'parch', 'cabin_letter', 'predicted_survival', 'survival_probability', 'created_at']
