# Titanic Survival Prediction API - Django Backend

API REST para predecir la supervivencia en el Titanic usando regresión logística.

## Instalación Local

\`\`\`bash
cd backend
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py runserver
\`\`\`

## Despliegue en Render

1. Conecta tu repositorio a Render
2. Crea un nuevo servicio Web
3. Selecciona Python como runtime
4. Usa el comando: `gunicorn config.wsgi:application --bind 0.0.0.0:8000`
5. Agrega las variables de entorno en Render dashboard

## Endpoints

- `POST /api/predict/` - Predecir supervivencia
- `GET /api/history/` - Historial de predicciones
- `GET /api/health/` - Health check

## Ejemplo de Request

\`\`\`json
{
  "age": 25,
  "pclass": 3,
  "sex": "male",
  "fare": 7.75,
  "sibsp": 0,
  "parch": 0,
  "cabin_letter": "U"
}
