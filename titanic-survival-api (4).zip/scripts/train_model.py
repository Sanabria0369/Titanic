import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import pickle
import requests
from io import StringIO

# Descargar el dataset del Titanic
url = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/titanic-PfabawRZpCY3WuMzJpfhfIiwlxcjdv.csv"
response = requests.get(url)
df = pd.read_csv(StringIO(response.text))

print("[v0] Dataset cargado. Shape:", df.shape)
print("[v0] Columnas:", df.columns.tolist())
print("[v0] Valores faltantes:\n", df.isnull().sum())

# Preparar datos
df_clean = df.copy()

# Llenar valores faltantes
df_clean['Age'].fillna(df_clean['Age'].median(), inplace=True)
df_clean['Embarked'].fillna(df_clean['Embarked'].mode()[0], inplace=True)
df_clean['Fare'].fillna(df_clean['Fare'].median(), inplace=True)

# Extraer número de camarote (primera letra)
df_clean['CabinLetter'] = df_clean['Cabin'].fillna('U').str[0]

# Seleccionar características
features = ['Pclass', 'Age', 'Fare', 'SibSp', 'Parch']
X = df_clean[features].copy()

# Codificar variables categóricas
X['Sex'] = (df_clean['Sex'] == 'male').astype(int)
X['CabinLetter_encoded'] = pd.Categorical(df_clean['CabinLetter']).codes

# Agregar Sex y CabinLetter a features
X = X[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch', 'Sex', 'CabinLetter_encoded']]
y = df_clean['Survived']

print("[v0] Features shape:", X.shape)
print("[v0] Target distribution:\n", y.value_counts())

# Dividir datos
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Escalar características
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Entrenar modelo de regresión logística
model = LogisticRegression(random_state=42, max_iter=1000)
model.fit(X_train_scaled, y_train)

# Evaluar modelo
train_score = model.score(X_train_scaled, y_train)
test_score = model.score(X_test_scaled, y_test)

print(f"[v0] Train accuracy: {train_score:.4f}")
print(f"[v0] Test accuracy: {test_score:.4f}")

# Guardar modelo y scaler
with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

print("[v0] Modelo guardado en model.pkl")
print("[v0] Scaler guardado en scaler.pkl")
