import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import json
import requests
from io import StringIO

# Descargar el dataset del Titanic desde el URL proporcionado
url = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/titanic-PfabawRZpCY3WuMzJpfhfIiwlxcjdv.csv"
response = requests.get(url)
df = pd.read_csv(StringIO(response.text))

print("[v0] Dataset cargado. Shape:", df.shape)
print("[v0] Columnas:", df.columns.tolist())

# Preparar datos
df_clean = df.copy()

# Llenar valores faltantes
df_clean['Age'].fillna(df_clean['Age'].median(), inplace=True)
df_clean['Embarked'].fillna(df_clean['Embarked'].mode()[0], inplace=True)
df_clean['Fare'].fillna(df_clean['Fare'].median(), inplace=True)

# Extraer letra del camarote
df_clean['CabinLetter'] = df_clean['Cabin'].fillna('U').str[0]

# Crear features
features = ['Pclass', 'Age', 'Fare', 'SibSp', 'Parch']
X = df_clean[features].copy()

# Codificar sexo (1 = male, 0 = female)
X['Sex'] = (df_clean['Sex'] == 'male').astype(int)

# Codificar letra del camarote
cabin_letters = sorted(df_clean['CabinLetter'].unique())
cabin_letter_map = {letter: idx for idx, letter in enumerate(cabin_letters)}
X['CabinLetter_encoded'] = df_clean['CabinLetter'].map(cabin_letter_map)

# Reordenar features
X = X[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch', 'Sex', 'CabinLetter_encoded']]
y = df_clean['Survived']

print("[v0] Features shape:", X.shape)
print("[v0] Target distribution:\n", y.value_counts())

# Dividir datos
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Escalar características
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Entrenar modelo de regresión logística
model = LogisticRegression(random_state=42, max_iter=1000)
model.fit(X_train_scaled, y_train)

# Evaluar modelo
train_score = model.score(X_train_scaled, y_train)
test_score = model.score(X_test_scaled, y_test)

print(f"[v0] Train accuracy: {train_score:.4f}")
print(f"[v0] Test accuracy: {test_score:.4f}")

# Exportar modelo como JSON
model_data = {
    "coefficients": model.coef_[0].tolist(),
    "intercept": float(model.intercept_[0]),
    "scaler_mean": scaler.mean_.tolist(),
    "scaler_scale": scaler.scale_.tolist(),
    "cabin_letter_map": cabin_letter_map,
    "feature_names": ['Pclass', 'Age', 'Fare', 'SibSp', 'Parch', 'Sex', 'CabinLetter_encoded']
}

with open('public/model.json', 'w') as f:
    json.dump(model_data, f)

print("[v0] Modelo exportado a public/model.json")
