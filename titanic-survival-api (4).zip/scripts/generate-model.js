// Script para generar el modelo ML en formato JSON
// Ejecutar: node scripts/generate-model.js

import fetch from "node-fetch"
import fs from "fs"
import path from "path"
import { fileURLToPath } from "url"

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// Implementación simple de regresión logística en JavaScript
class SimpleLogisticRegression {
  constructor() {
    this.coefficients = null
    this.intercept = null
    this.scalerMean = null
    this.scalerScale = null
  }

  fit(X, y) {
    const n = X.length
    const m = X[0].length

    // Calcular media y desviación estándar para normalización
    this.scalerMean = new Array(m).fill(0)
    this.scalerScale = new Array(m).fill(0)

    for (let j = 0; j < m; j++) {
      let sum = 0
      for (let i = 0; i < n; i++) {
        sum += X[i][j]
      }
      this.scalerMean[j] = sum / n
    }

    for (let j = 0; j < m; j++) {
      let sumSq = 0
      for (let i = 0; i < n; i++) {
        sumSq += Math.pow(X[i][j] - this.scalerMean[j], 2)
      }
      this.scalerScale[j] = Math.sqrt(sumSq / n) || 1
    }

    // Normalizar X
    const XNorm = X.map((row) => row.map((val, j) => (val - this.scalerMean[j]) / this.scalerScale[j]))

    // Inicializar coeficientes
    this.coefficients = new Array(m).fill(0.1)
    this.intercept = 0

    // Gradient descent simple
    const learningRate = 0.01
    const iterations = 100

    for (let iter = 0; iter < iterations; iter++) {
      for (let i = 0; i < n; i++) {
        let z = this.intercept
        for (let j = 0; j < m; j++) {
          z += this.coefficients[j] * XNorm[i][j]
        }
        const pred = 1 / (1 + Math.exp(-z))
        const error = pred - y[i]

        this.intercept -= learningRate * error
        for (let j = 0; j < m; j++) {
          this.coefficients[j] -= learningRate * error * XNorm[i][j]
        }
      }
    }
  }

  predict(X) {
    return X.map((row) => {
      let z = this.intercept
      for (let j = 0; j < row.length; j++) {
        const normalized = (row[j] - this.scalerMean[j]) / this.scalerScale[j]
        z += this.coefficients[j] * normalized
      }
      return 1 / (1 + Math.exp(-z))
    })
  }
}

async function generateModel() {
  try {
    console.log("[v0] Descargando dataset del Titanic...")
    const response = await fetch(
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/titanic-PfabawRZpCY3WuMzJpfhfIiwlxcjdv.csv",
    )
    const csv = await response.text()

    // Parsear CSV simple
    const lines = csv.trim().split("\n")
    const headers = lines[0].split(",")
    const data = lines.slice(1).map((line) => {
      const values = line.split(",")
      const row = {}
      headers.forEach((header, idx) => {
        row[header.trim()] = values[idx]?.trim()
      })
      return row
    })

    console.log(`[v0] Dataset cargado: ${data.length} registros`)

    // Preparar features
    const X = []
    const y = []
    const cabinLetters = new Set()

    for (const row of data) {
      if (!row.Survived || !row.Pclass || !row.Age || !row.Sex) continue

      const age = Number.parseFloat(row.Age)
      const fare = Number.parseFloat(row.Fare) || 0
      const pclass = Number.parseInt(row.Pclass)
      const sibsp = Number.parseInt(row.SibSp) || 0
      const parch = Number.parseInt(row.Parch) || 0
      const sex = row.Sex === "male" ? 1 : 0
      const cabin = row.Cabin ? row.Cabin[0] : "U"
      const survived = Number.parseInt(row.Survived)

      cabinLetters.add(cabin)
      X.push([pclass, age, fare, sibsp, parch, sex, cabin])
      y.push(survived)
    }

    // Mapear letras de camarote
    const cabinLetterMap = {}
    Array.from(cabinLetters)
      .sort()
      .forEach((letter, idx) => {
        cabinLetterMap[letter] = idx
      })

    // Convertir camarotes a números
    const XNumeric = X.map((row) => [row[0], row[1], row[2], row[3], row[4], row[5], cabinLetterMap[row[6]]])

    console.log(`[v0] Features preparados: ${XNumeric.length} muestras`)

    // Entrenar modelo
    const model = new SimpleLogisticRegression()
    model.fit(XNumeric, y)

    console.log("[v0] Modelo entrenado")

    // Guardar modelo
    const modelData = {
      coefficients: model.coefficients,
      intercept: model.intercept,
      scaler_mean: model.scalerMean,
      scaler_scale: model.scalerScale,
      cabin_letter_map: cabinLetterMap,
      feature_names: ["Pclass", "Age", "Fare", "SibSp", "Parch", "Sex", "CabinLetter_encoded"],
    }

    const modelPath = path.join(__dirname, "../public/model.json")
    fs.writeFileSync(modelPath, JSON.stringify(modelData, null, 2))

    console.log(`[v0] Modelo guardado en ${modelPath}`)
    console.log("[v0] Coeficientes:", model.coefficients)
    console.log("[v0] Intercept:", model.intercept)
  } catch (error) {
    console.error("[v0] Error generando modelo:", error)
    process.exit(1)
  }
}

generateModel()
